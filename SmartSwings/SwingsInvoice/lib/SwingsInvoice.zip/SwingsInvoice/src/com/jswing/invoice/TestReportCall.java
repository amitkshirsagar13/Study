package com.jswing.invoice;

/**
 * ProjectName: SwingsInvoice
 * @author amit_kshirsagar
 * @date Jan 16, 2014
 */

import java.sql.Connection;
import java.sql.Statement;
import java.util.HashMap;
import java.util.logging.Logger;

import com.jswing.invoice.report.Report;
import com.jswing.invoice.util.Database;

public class TestReportCall {
	static Logger log = Logger.getLogger(TestReportCall.class.getName());

	public static void main(String[] args) {
		Connection connection = null;
		Statement statement = null;
		try {
			connection = Database.getConnection();
			// statement = connection.createStatement();
			HashMap parameterMap = new HashMap();
			parameterMap.put("rtitle", "Report Title Here");// sending the
															// report title as a
															// parameter.
			Report rpt = new Report(parameterMap, connection);
			rpt.setReportName("samplelist"); // productlist is the name of my
												// jasper file.
			rpt.callReport();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				statement.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}