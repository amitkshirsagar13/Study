#!/bin/sh

if [ -z /usr/bin/conky ]; then
	sudo apt-get install conky
else
	echo "Conky module already installed..."
fi
echo "Now Installing Conky.. from Amit Kshirsagar...."
cp -R .bin ~/
cp -R .Conky ~/
chmod -R 755 ~/.bin
chmod -R 755 ~/.Conky
