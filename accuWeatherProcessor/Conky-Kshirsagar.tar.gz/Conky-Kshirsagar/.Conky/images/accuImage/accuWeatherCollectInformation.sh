#!/bin/bash

/usr/bin/java -jar ~/.Conky/images/accuImage/accuWeather.jar `pwd` > ~/.Conky/images/accuImage/log/accuWeatherProcessor.log
~/.Conky/images/accuImage/imageTemp.sh &
